#!/bin/bash

# Bash Color
green='\033[01;32m'
red='\033[01;31m'
cyan='\033[01;36m'
blue='\033[01;34m'
blink_red='\033[05;31m'
restore='\033[0m'

clear

# Paths
kernel_src="/home/hyper/kernel/x2"
clang_path="/home/hyper/losp/prebuilts/clang/host/linux-x86/clang-4691093/bin"
toolchain_dir="/home/hyper/losp/prebuilts/gcc/linux-x86/aarch64/aarch64-linux-android-4.9"
out_dir="/home/hyper/kernel/out-x2"
zip_dir="/home/hyper/kernel/release-x2"
dtbo_path="$zip_dir/dtbo.img"
kimage_path="$out_dir/arch/arm64/boot/Image-dtb"

# File
zip_file=`find $zip_dir -name \*.zip`

# Hyper Kernel version
BASE_VER="hyper-p"
VER="-$(date +"%Y-%m-%d"-%H%M)"
K_VER="$BASE_VER$VER-RMX1931"

# Config
def_config="vendor/sm8150-perf_defconfig"

# libufdt
mkdtpy="/home/hyper/losp/system/libufdt/utils/src/mkdtboimg.py"

# Exports
export KBUILD_BUILD_USER=karthick111
export PATH=${clang_path}:${PATH}
export CLANG_TRIPLE=aarch64-linux-gnu-

if [ ! -d "$out_dir" ]; then
	mkdir -p $out_dir
fi

if [ ! -d "$zip_dir" ]; then
	mkdir -p $zip_dir
fi

# Task
cd $kernel_src

DATE_START=$(date +"%s")

buildit() {
make CC=clang O=$out_dir ARCH=arm64 $def_config
make CC=clang -j$(nproc --all) O=$out_dir DTC_EXT="/home/hyper/losp/prebuilts/misc/linux-x86/dtc/dtc" \
	ARCH=arm64 \
	SUBARCH=arm64 \
	HEADER_ARCH=arm64 \
	LD_LIBRARY_PATH="$toolchain_dir/aarch64-linux-gnu/lib64" \
	CROSS_COMPILE="$toolchain_dir/bin/aarch64-linux-android-"| pv -t
python2 "$mkdtpy" create "$zip_dir"/dtbo.img $(find "$out_dir"/arch/arm64/boot/dts -iname '*-overlay.dtbo' -print)
        zipit
}

zipit() {
if [ -f "$kimage_path" ]; then
	cp "$out_dir"/arch/arm64/boot/Image-dtb "$zip_dir"
	cd "$zip_dir"
        zip -r9 `echo $K_VER`.zip . -x *.zip
	echo -e "Completed."
        transfer *.zip # shit never worked when required
#	scp -P 22222 $K_VER.zip hyper@hyper.remainsilent.net:/home/hyper/.dl/rmx
	#echo -e "Transfered."
        echo -e "${green}"
        echo $K_VER.zip
        echo "------------------------------------------"
        echo -e "${restore}"
else
	echo "Error..."
	exit 1
fi
}

cleanit() {
if [ "$zip_file" != "" ]; then
	rm -rf "$out_dir"
	for i in `find $zip_dir -name \*.zip`;do rm -rf "$i";echo -e "deleted $i";
	done;
	rm -rf $zip_dir/Image-dtb $zip_dir/dtbo.img
fi
}

echo -e "${restore}"
           cleanit
           buildit

DATE_END=$(date +"%s")
DIFF=$(($DATE_END - $DATE_START))
echo "Time: $(($DIFF / 60)) minute(s) and $(($DIFF % 60)) seconds."
echo " "

cd $kernel_src
